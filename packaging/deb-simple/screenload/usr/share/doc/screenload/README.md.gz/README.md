<div align="center">
  <p>
    <h1>
      <a href="https://github.com/second-level/screenload">
        <img src="data/img/app/ru.screenload.ScreenLoad.svg" alt="ScreenLoad" />
      </a>
      <br />
      ScreenLoad
    </h1>
    <h4>Powerful yet simple to use screenshot software.</h4>
  </p>
</div>